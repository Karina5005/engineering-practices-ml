# Engineering-practices-ml

## Форматирование
* black
* isort
## Плагины flake8
* flake8-requirements
* flake8-warnings
* flake8-comprehensions
* flake8-quotes 
* flake8-return 
* flake8-variables-names